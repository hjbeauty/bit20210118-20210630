import React from 'react';
import AppLayout from '../components/common/AppLayout';
import Test from '../components/test';
const TEST = () => (
  <div>
    <AppLayout>
      <Test />
    </AppLayout>
  </div>
);

export default TEST;
