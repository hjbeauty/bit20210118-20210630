export default function error404() {
  return (
    <div>
      <h1>404 - Page Not Found</h1>
    </div>
  );
}
